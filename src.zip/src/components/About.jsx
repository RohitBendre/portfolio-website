import styles from './About.module.css';

export default function About() {
  return (
    <div className={styles.about}>
      <p>
  Hello! I'm Rohit, a passionate developer with a strong interest in crafting beautiful and functional web experiences. With a background in computer science and a love for clean, efficient code, I enjoy building web applications that are not only visually appealing but also performance-oriented. I'm currently expanding my skills in modern frontend and backend technologies, and I'm always eager to learn and take on new challenges. When I'm not coding, you'll probably find me exploring design trends, learning about new tech tools, or enjoying a good cup of coffee while planning my next project.
</p>    
<p>I'm a passionate and detail-oriented developer with a strong foundation in front-end and back-end technologies. I enjoy turning complex problems into elegant, user-friendly solutions. My work is driven by curiosity and a constant desire to grow, whether it's learning a new framework, optimizing code, or collaborating on meaningful projects. Beyond code, I value clean design, clear communication, and continuous learning.</p>
 <p>I'm always excited to take on new challenges that push my boundaries and help me grow as a developer. Let’s build something great together.</p>
</div>
  );
}
