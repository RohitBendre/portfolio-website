import styles from './Projects.module.css';

export default function Projects() {
  return (
    <div className={styles.projects}>
      <h2>Projects</h2>
      <div className={styles.projectList}>
        <div className={styles.projectCard}>
          <h3>Project 1</h3>
          <p>Description of the project.</p>
        </div>
        <div className={styles.projectCard}>
          <h3>Project 2</h3>
          <p>Description of the project.</p>
        </div>
        <div className={styles.projectCard}>
          <h3>Project 2</h3>
          <p>Description of the project.</p>
        </div>
        <div className={styles.projectCard}>
          <h3>Project 2</h3>
          <p>Description of the project.</p>
        </div>
        <div className={styles.projectCard}>
          <h3>Project 2</h3>
          <p>Description of the project.</p>
        </div>
        <div className={styles.projectCard}>
          <h3>Project 2</h3>
          <p>Description of the project.</p>
        </div>
        <div className={styles.projectCard}>
          <h3>Project 2</h3>
          <p>Description of the project.</p>
        </div>
        <div className={styles.projectCard}>
          <h3>Project 2</h3>
          <p>Description of the project.</p>
        </div>
        {/* Add more projects here */}
      </div>
    </div>
  );
}
